# logic_ops.py
# IT 405L - Activity 1: Logical Operators and an Expression Evaluator

# 1. NOT Operator (comparisons only, no built-in not)
def my_not(a):
    if a == True:
        return False
    return True


# 2. AND Operator (comparisons only, no built-in and)
def my_and(a, b):
    if a == True:
        return b == True
    return False


# 3. OR Operator (comparisons only, no built-in or)
def my_or(a, b):
    if a == True:
        return True
    return b == True


# 4. IMPLIES Operator (comparisons only, false only when True -> False)
def my_implies(a, b):
    if a == True:
        return b == True
    return True


# 5. Recursive Tree Evaluator
def evaluate(expr):
    # Base case: Leaf node (boolean value)
    if isinstance(expr, bool):
        return expr

    # Extract operator name
    op = expr[0]

    # Unary branch
    if op == 'not':
        operand = evaluate(expr[1])
        return my_not(operand)

    # Binary branches (evaluate operands eagerly)
    left = evaluate(expr[1])
    right = evaluate(expr[2])

    if op == 'and':
        return my_and(left, right)
    elif op == 'or':
        return my_or(left, right)
    elif op == 'implies':
        return my_implies(left, right)
    else:
        raise ValueError(f"Unknown operator: {op}")