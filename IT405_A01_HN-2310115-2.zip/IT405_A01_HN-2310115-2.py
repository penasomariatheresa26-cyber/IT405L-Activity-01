import hashlib
from logic_ops import evaluate

STUDENT_ID = "HN-2310115-2"

# Look at your paper slip for your assigned EXPR:
# Replace this line with the exact EXPR printed on your parameter slip:
EXPR = ("and", True, ("not", ("or", False, False)))

result = evaluate(EXPR)
raw_stamp = f"{STUDENT_ID}:{EXPR}:{result}".encode("utf-8")
stamp = hashlib.sha256(raw_stamp).hexdigest()

print(f"STAMP: {stamp}")